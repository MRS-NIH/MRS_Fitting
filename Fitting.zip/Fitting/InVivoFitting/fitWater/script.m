clear; close all; clc

% MRS parameters
mrsPars.freq = 127.73;
mrsPars.sw = 5;
mrsPars.np = 4096;
mrsPars.rfoffset = 4.67;
mrsPars.basisRFoffset = 4.67;
mrsPars.zf = 2 * mrsPars.np;
mrsPars.ff = -0.5*mrsPars.sw : mrsPars.sw/(mrsPars.zf-1) : 0.5*mrsPars.sw;
mrsPars.ppm = mrsPars.rfoffset + 1000*mrsPars.ff/mrsPars.freq;

% LCM fitting parameters
lcmPars.fitRange = [3.5 5.5];
lcmPars.pointBsl = 10;
lcmPars.maxiter = 200;

% Read data
dataLoad = '\Data_NAA_Glu\InVivo\OCC\';

FID = readData([dataLoad 'waterFID.dat']);
FID = reshape(FID,mrsPars.np,1);
spec = fftshift(fft(FID,mrsPars.zf));

% Reference to water at 4.67 ppm
water = 4.67;

offset = water;
offsetTolHz = 12.5;                            % Search range (in Hz)
offsetTolppm = offsetTolHz / mrsPars.freq;     % Search range (in ppm)

coor = find((mrsPars.ppm < (offset + offsetTolppm)) & ...
    (mrsPars.ppm > (offset - offsetTolppm)));
[maxspec,maxpos] = max(abs(spec(coor)));

refOffsetppm = mrsPars.ppm(coor(1)+maxpos-1);
mrsPars.rfoffset = mrsPars.rfoffset + (water - refOffsetppm);
mrsPars.ppm = mrsPars.rfoffset + 1000*mrsPars.ff/mrsPars.freq;

% basis data
name = {'water'};

basisDir = '\InVivoFitting\BasisSet\';
nBasis = length(name);

fileName = [basisDir,name{1}];
basis = readData(fileName);

% set init, LB, UB
%**********************
% First two are global values for phase and fraction
%**********************
count = 1;

init = [0.0 0.5];
LB = [-pi 0];
UB = [pi 1];

count = count + 2;

% amplitude
init(count) = 250000; 
LB(count) = 0;
UB(count) = 1000000;

% line-broadening
init(count+1) = 9;
LB(count+1) = 3;
UB(count+1) = 20;

% frequency shift
init(count+2) = 0;
LB(count+2) = -5;
UB(count+2) = 5;

count = count + 3;

mrsPars.ampCount = 3;

%*****************
% Spline baseline
%*****************
init = [init zeros(1,lcmPars.pointBsl) 1];
LB = [LB -70*ones(1,lcmPars.pointBsl) -3];
UB = [UB 70*ones(1,lcmPars.pointBsl) 3];

%********************************************
% Determine data points used for LCM fitting
%********************************************
[~,lowIdx] = min(abs(mrsPars.ppm - lcmPars.fitRange(1)));
[~,highIdx] = min(abs(mrsPars.ppm - lcmPars.fitRange(2)));

fitRange = lowIdx : highIdx;
xdata = reshape(fitRange,length(fitRange),1);
ydata = real(spec(xdata)); % xdata+1

%*********************************************
% Set optimization parameters for LCM fitting
%*********************************************
tolfun = 1e-10;
maxfuneval = lcmPars.maxiter * (length(init)+1);

opt = optimset('Tolfun',tolfun,'MaxFunEval',maxfuneval,'LargeScale','on','DerivativeCheck','off','FinDiffType','central', ...
    'MaxIter',lcmPars.maxiter,'Display','iter','DiffMinChange',1e-8,'UseParallel','always');

%*********************
% Perform LCM fitting
%*********************
[lcmFit,resnorm,residual,exitflag,output,lambda,jacobian] = ...
    lsqcurvefit('costFun',init,xdata,ydata,LB,UB,opt,ydata,basis,nBasis,mrsPars,lcmPars);

%*********************************
% Display and save fitting result
%*********************************
ReconDispSpec(lcmFit,spec,basis,mrsPars,lcmPars,dataLoad);

amp = lcmFit(3);
lw = lcmFit(4);
fs = lcmFit(5);

fprintf('metabolite   conc    shift [Hz]  broadening [Hz]\n');
for i = 1 : length(name)
    fprintf('%4s        %4.3f      %4.3f    %4.3f\n', ...
        name{i},amp(i),fs(i),lw(i));
end
