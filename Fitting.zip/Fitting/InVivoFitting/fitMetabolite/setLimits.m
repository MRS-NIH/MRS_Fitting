function [init,LB,UB,ampCount] = setLimits(nBasis,lcmPars)

%**********************
% First two are global values for phase and fraction
%**********************
count = 1;

init = [0.0 0.5];
LB = [-pi 0];
UB = [pi 1];

count = count + 2;

%**********************
% set init, LB, UB
%**********************
ampCount =  [];

for i = 1 : nBasis
    
    % amplitude
    LB(count) = 0;
    UB(count) = Inf;
    init(count) = 1000;
    
    ampCount = [ampCount count];
    
    % line-broadening
    LB(count+1) = 3;
    UB(count+1) = 11;
    init(count+1) = (LB(count+1) +  UB(count+1)) / 2;
    
    % frequency shift
    LB(count+2) = -5;
    UB(count+2) = 5;
    init(count+2) = (LB(count+2) +  UB(count+2)) / 2;
    
    count = count + 3;
    
end

%*****************
% Spline baseline
%*****************
init = [init zeros(1,lcmPars.pointBsl) 1];
LB = [LB -70*ones(1,lcmPars.pointBsl) -3];
UB = [UB 70*ones(1,lcmPars.pointBsl) 3];
