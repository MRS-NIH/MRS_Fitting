clear; close all; clc

% MRS parameters
mrsPars.freq = 127.73;
mrsPars.sw = 5;
mrsPars.np = 4096;
mrsPars.rfoffset = 4.67;
mrsPars.basisRFoffset = 4.67;
mrsPars.zf = 2 * mrsPars.np;
mrsPars.ff = -0.5*mrsPars.sw : mrsPars.sw/(mrsPars.zf-1) : 0.5*mrsPars.sw;
mrsPars.ppm = mrsPars.rfoffset + 1000*mrsPars.ff/mrsPars.freq;

% LCM fitting parameters
lcmPars.fitRange = [1.8 4.2];
lcmPars.pointBsl = 10;
lcmPars.maxiter = 200;

% Read data
dataLoad = '\Data_NAA_Glu\InVivo\OCC\';

FID = readData([dataLoad 'metaboliteFID.dat']);
FID = reshape(FID,mrsPars.np,1);
spec = fftshift(fft(FID,mrsPars.zf));

% Reference to tCr at 3.03 ppm
tCr = 3.03;

offset = tCr;
offsetTolHz = 12.5;                            % Search range (in Hz)
offsetTolppm = offsetTolHz / mrsPars.freq;     % Search range (in ppm)

coor = find((mrsPars.ppm < (offset + offsetTolppm)) & ...
    (mrsPars.ppm > (offset - offsetTolppm)));
[maxspec,maxpos] = max(abs(spec(coor)));

refOffsetppm = mrsPars.ppm(coor(1)+maxpos-1);
mrsPars.rfoffset = mrsPars.rfoffset + (tCr - refOffsetppm);
mrsPars.ppm = mrsPars.rfoffset + 1000*mrsPars.ff/mrsPars.freq;

%**********************
% Load basis data
%**********************
name = {'NAA','Glu','NAAG','tCr','tCho','mI','Asp','GABA',...
    'Glc','Gln','Gly','GSH','PE','sI','Tau'};

basisDir = '\InVivoFitting\BasisSet\';
nBasis = length(name);

for i = 1 : nBasis
    
    fileName = [basisDir,name{i}];
    basis(i,:) = readData(fileName);
    
end

%***************************************
% set initial, low and upper boundaries
%***************************************
[init,LB,UB,ampCount] = setLimits(nBasis,lcmPars);
lcmPars.init = init;
lcmPars.LB = LB;
lcmPars.UB = UB;

%********************************************
% Determine data points used for LCM fitting
%********************************************
[~,lowIdx] = min(abs(mrsPars.ppm - lcmPars.fitRange(1)));
[~,highIdx] = min(abs(mrsPars.ppm - lcmPars.fitRange(2)));

fitRange = lowIdx : highIdx;
xdata = reshape(fitRange,length(fitRange),1);
ydata = real(spec(xdata));

%*********************************************
% Set optimization parameters for LCM fitting
%*********************************************
tolfun = 1e-10;
maxfuneval = lcmPars.maxiter * (length(init)+1);

opt = optimset('Tolfun',tolfun,'MaxFunEval',maxfuneval,'LargeScale','on','DerivativeCheck','off','FinDiffType','central', ...
    'MaxIter',lcmPars.maxiter,'Display','iter','DiffMinChange',1e-8,'UseParallel','always');

%*********************
% Perform LCM fitting
%*********************
[lcmFit,resnorm,residual,exitflag,output,lambda,jacobian] = ...
    lsqcurvefit('costFun',init,xdata,ydata,LB,UB,opt,ydata,basis,nBasis,mrsPars,lcmPars);

%*********************************
% Display and save fitting result
%*********************************
ReconDispSpec(lcmFit,spec,basis,mrsPars,lcmPars,dataLoad,nBasis);

amp = lcmFit(3:3:end);
lw = lcmFit(4:3:end);
fs = lcmFit(5:3:end);

fprintf('metabolite   conc    shift [Hz]  broadening [Hz]\n');
for i = 1 : length(name)
    fprintf('%4s        %4.3f      %4.3f    %4.3f\n', ...
        name{i},amp(i),fs(i),lw(i));
end

