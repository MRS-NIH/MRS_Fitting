function F = costFun(coeff,xdata,ydata,basisFID,nBasis,mrsPars,lcmPars)

dt = 1 / (1000*mrsPars.sw);     % Dwell-time
time = dt * (0 : (mrsPars.np-1));

count = 1;
phs = coeff(count);
fraction = coeff(count+1);
count = count + 2;

countBasis = 1;
fidFit = zeros(1,mrsPars.np);

for i = 1 : nBasis
    
        amp = coeff(count);
        
        lorPart = basisFID(countBasis,:) .* exp(-pi*coeff(count+1)*time);
        gauPart = basisFID(countBasis,:) .* exp(-(pi*coeff(count+1)/(2*sqrt(log(2))))^2*time.*time);
        
        tmp = amp * exp(1i*phs) * ((fraction * lorPart) + ((1-fraction) * gauPart)) .* ...
            exp(2*pi*1i*coeff(count+2)*time);
        
        count = count + 3;
        countBasis = countBasis + 1;
        
    fidFit = fidFit + tmp;
    
    clear amp lorPart gauPart tmp
end

%***************************************************
% Correct global offset between data and basis set
%***************************************************
fidFit = fidFit .* ...
    exp(2*pi*1i*(mrsPars.basisRFoffset-mrsPars.rfoffset)*mrsPars.freq*time);

%***************************************************
% Fourier transformation (optional zero filling)
%***************************************************
specFit = fftshift(fft(fidFit,mrsPars.zf));

%***************************************************
% Spline baseline
%***************************************************
specFit = reshape(specFit,length(specFit),1);
specFitROI = real(specFit(xdata)); 

x = 1 : size(specFitROI,1);
x = reshape(x,size(specFitROI,1),1);

splCoefs = coeff(count : count+lcmPars.pointBsl-1);
splCoefs = reshape(splCoefs,length(splCoefs),1);
splScale = coeff(end);
splCoefScl = splScale .* splCoefs;

xSpline = linspace(x(1),x(end),lcmPars.pointBsl);
xSpline = reshape(xSpline,length(xSpline),1);
bsl = spline(xSpline,splCoefScl,x);

F = specFitROI + bsl;
