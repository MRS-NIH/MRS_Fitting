function ReconDispSpec(lcmFit,spec,basisFID,mrsPars,lcmPars,dataLoad)

dt = 1 / (1000*mrsPars.sw);                 % Dwell-time
time = dt * (0 : (mrsPars.np-1));

count = 1;
phs = lcmFit(count);
fraction = lcmFit(count+1);
count = count + 2;

countBasis = 1;
fidFit = zeros(1,mrsPars.np);

%
amp = lcmFit(count);

lorPart = basisFID(countBasis,:) .* exp(-pi*lcmFit(count+1)*time);
gauPart = basisFID(countBasis,:) .* exp(-(pi*lcmFit(count+1)/(2*sqrt(log(2))))^2*time.*time);

tmp = amp * exp(1i*phs) * ((fraction * lorPart) + ((1-fraction) * gauPart)) .* ...
    exp(2*pi*1i*lcmFit(count+2)*time);

count = count + 3;
fidFit = fidFit + tmp;


%***************************************************
% Correct global offset between data and basis set
%***************************************************
fidFit = fidFit .* ...
    exp(2*pi*1i*(mrsPars.basisRFoffset-mrsPars.rfoffset)*mrsPars.freq*time);

%***************************************************
% Fourier transformation (optional zero filling)
%***************************************************
specFit = fftshift(fft(fidFit,mrsPars.zf));

%***************************************************
% Spline baseline
%***************************************************
[~,lowIdx] = min(abs(mrsPars.ppm - lcmPars.fitRange(1)));
[~,highIdx] = min(abs(mrsPars.ppm - lcmPars.fitRange(2)));

xdata = lowIdx : highIdx;

spec = reshape(spec,1,length(spec));

rawSpec = real(spec(xdata)); %xdata+1
fitSpec = real(specFit(xdata)); %xdata+1

x = 1 : length(fitSpec);

splCoefs = lcmFit(count : count+lcmPars.pointBsl-1);
splScale = lcmFit(end);
splCoefs1 = splScale .* splCoefs;

xSpline = linspace(x(1),x(end),lcmPars.pointBsl);
bsl = spline(xSpline,splCoefs1,x);

residual = rawSpec - fitSpec - bsl;

ppm = mrsPars.ppm(xdata);

% Display and save fitting results
fontsize = 11;
LW = 1.25;

if min(bsl) > min(rawSpec)
    minY = min(rawSpec);
else
    minY = min(bsl);
end

minY = minY - 150;
maxY = max(residual) + max(rawSpec) + 150;

figure('units','inch','Position',[2 2 7 2.5]);

plot(ppm,real(rawSpec),'LineWidth',LW,'Color',[0 0 0])
hold on; plot(ppm,real(fitSpec+bsl),'LineWidth',LW,'Color',[1 0 0])
plot(ppm,bsl,'LineWidth',LW,'Color',[0 0 0])
plot(ppm,residual+max(rawSpec)+50,'LineWidth',LW,'Color',[0 0 0])

xlim([lcmPars.fitRange(1) lcmPars.fitRange(2)])
xticks([3.5 4.0 4.5 5.0 5.5]); xticklabels({'3.5','4.0','4.5','5.0','5.5'})
set(gca,'XDir','reverse','FontSize',fontsize,'LineWidth',LW,'box','off','ycolor','none')
ylim([minY maxY])

% save
saveas(gcf,[dataLoad 'lcmFitResults.pdf'])